
<?php
require_once 'dompdf/autoload.inc.php';
  // reference the Dompdf namespace
  use Dompdf\Dompdf;    
$message='';
if (isset($_POST['htmlPdf'])) {
   
  
   $pdf = new Dompdf();

   $file_name = md5(rand()).'.pdf';
   $html_code = '<link rel="stylesheet" href="C:/xampp/htdocs/html-to-pdf/dompdf/src/Css/bootstrap.css" />';
   $html_code .="<h1 class='text-danger'>Hello World</h1>";
   $html_code .="<img src='C:/xampp/htdocs/html-to-pdf/dompdf/img/ram.jpg' class='img-fluid'>";

   
  

   $pdf->load_html($html_code);
   $pdf->render();
   $file = $pdf->output();
   file_put_contents("invoice/".$file_name, $file);
   // file_put_contents(filename, data)
   // $pdf->stream();
}


?>


<!DOCTYPE html>
<html>
<head>
  <title>html to pdf</title>
  <link rel="stylesheet" href="bootstrap.css" />
</head>

<body>
  <h2>html to pdf conver and download by defaultly</h2>
 
  <form method="post" action="">
    <input type="submit" name="htmlPdf" value="Create Pdf" class="btn btn-primary">
  </form>

</body>
</html>